nohup python -m algorithms.yelp.CF_train_A2C > output_A2C_NonPosResPos.txt &
nohup python -m algorithms.yelp.CF_train_DQN > output_DQN_NonPosResPos.txt &
nohup python -m algorithms.yelp.CF_train_PPO > output_PPO_NonPosResPos.txt &
nohup python -m algorithms.yelp.CF_train_TRPO > output_TRPO_NonPosResPos.txt 

